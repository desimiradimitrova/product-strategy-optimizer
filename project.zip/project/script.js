// Основни данни
let products = [];
let packages = {
    1: { items: [], utility: 0, price: 0, profit: 0 },
    2: { items: [], utility: 0, price: 0, profit: 0 },
    3: { items: [], utility: 0, price: 0, profit: 0 }
};
let surveyScale = 7;
let customerGroups = [
    "Жени 20-30г.",
    "Жени 30-50г.",
    "Мъже 20-30г.",
    "Мъже 30-50г."
];
let surveyResults = {};
let payoffMatrix = [];
let chart = null;

// Инициализация
function init() {
    updateProductSelect();
    updatePayoffMatrix();
}

// Навигация между табове
function openTab(tabName) {
    const tabs = document.getElementsByClassName("tab");
    const tabContents = document.getElementsByClassName("tab-content");
    
    for (let i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove("active");
        tabContents[i].classList.remove("active");
    }
    
    document.getElementById(tabName).classList.add("active");
    document.querySelector(`.tab[onclick="openTab('${tabName}')"]`).classList.add("active");
}

// Добавяне на нов продукт
function addProduct() {
    const name = document.getElementById("productName").value;
    const time = parseFloat(document.getElementById("productTime").value);
    const price = parseFloat(document.getElementById("productPrice").value);
    const cost = parseFloat(document.getElementById("productCost").value);
    
    if (!name || isNaN(time) || isNaN(price) || isNaN(cost)) {
        alert("Моля въведете валидни данни за продукта!");
        return;
    }
    
    const profit = price - cost;
    const profitPercentage = (profit / price) * 100;
    
    const newProduct = {
        id: Date.now().toString() + Math.random().toString(36).substring(2, 15),
        name: name,
        time: time,
        price: price,
        cost: cost,
        profit: profit,
        profitPercentage: profitPercentage,
        utility: 0 // ще се изчисли по-късно
    };
    
    products.push(newProduct);
    updateProductUtility();
    renderProductsTable();
    updateProductSelect();
    updateSurveyProducts();
    
    // Изчистване на полетата
    document.getElementById("productName").value = "";
    document.getElementById("productTime").value = "";
    document.getElementById("productPrice").value = "";
    document.getElementById("productCost").value = "";
}

// Изчисляване на полезността на всички продукти
function updateProductUtility() {
    if (products.length === 0) return;
    
    // Намиране на най-дългото време за изработка
    const maxTime = Math.max(...products.map(p => p.time));
    
    // Изчисляване на полезността за всеки продукт
    products.forEach(product => {
        // Формула: 0.6 * (1 - (време/най-дълго време)) + 0.4 * (процент печалба/100)
        const timeComponent = 0.6 * (1 - (product.time / maxTime));
        const profitComponent = 0.4 * (product.profitPercentage / 100);
        product.utility = timeComponent + profitComponent;
        product.utility = parseFloat(product.utility.toFixed(3));
    });
}

// Визуализация на таблицата с продукти
function renderProductsTable() {
    const tableBody = document.getElementById("productsTableBody");
    tableBody.innerHTML = "";
    
    // Сортиране на продуктите по полезност (в низходящ ред)
    const sortedProducts = [...products].sort((a, b) => b.utility - a.utility);
    
    sortedProducts.forEach((product, index) => {
        const originalIndex = products.findIndex(p => p.id === product.id);
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${product.name}</td>
            <td>${product.time}</td>
            <td>${product.price.toFixed(2)}</td>
            <td>${product.cost.toFixed(2)}</td>
            <td>${product.profit.toFixed(2)}</td>
            <td>${product.profitPercentage.toFixed(2)}%</td>
            <td>${product.utility.toFixed(3)}</td>
            <td>
                <button onclick="removeProduct(${originalIndex})">Премахни</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Премахване на продукт
function removeProduct(index) {
    products.splice(index, 1);
    if (products.length > 0) {
        updateProductUtility();
    }
    renderProductsTable();
    updateProductSelect();
    updateSurveyProducts();
    
    // Актуализиране на пакетите, ако продуктът е премахнат
    for (let packageId in packages) {
        packages[packageId].items = packages[packageId].items.filter(item => {
            const product = products.find(p => p.id === item.productId);
            return product !== undefined;
        });
        updatePackageSummary(packageId);
    }
}

// Актуализиране на падащите менюта за избор на продукт
function updateProductSelect() {
    for (let i = 1; i <= 3; i++) {
        const select = document.getElementById(`productSelect${i}`);
        if (select) {
            select.innerHTML = "";
            
            products.forEach(product => {
                const option = document.createElement("option");
                option.value = product.id;
                option.textContent = `${product.name} (${product.price.toFixed(2)} лв.)`;
                select.appendChild(option);
            });
        }
    }
}

// Добавяне на продукт към пакет
function addToPackage(packageId) {
    const select = document.getElementById(`productSelect${packageId}`);
    const quantity = parseInt(document.getElementById(`productQuantity${packageId}`).value);
    
    if (products.length === 0) {
        alert("Няма въведени продукти!");
        return;
    }
    
    if (select.value && quantity > 0) {
        const productId = select.value;
        const product = products.find(p => p.id === productId);
        
        if (product) {
            packages[packageId].items.push({
                productId: productId,
                quantity: quantity
            });
            
            updatePackageSummary(packageId);
        }
    }
}

// Премахване на продукт от пакет
function removeFromPackage(packageId, itemIndex) {
    packages[packageId].items.splice(itemIndex, 1);
    updatePackageSummary(packageId);
}

// Актуализиране на информацията за пакет
function updatePackageSummary(packageId) {
    const packageItems = packages[packageId].items;
    const packageElement = document.getElementById(`package${packageId}Items`);
    
    if (!packageElement) return;
    
    packageElement.innerHTML = "";
    
    let totalUtility = 0;
    let totalPrice = 0;
    let totalProfit = 0;
    
    packageItems.forEach((item, index) => {
        const product = products.find(p => p.id === item.productId);
        if (product) {
            const itemUtility = product.utility * item.quantity;
            const itemPrice = product.price * item.quantity;
            const itemProfit = product.profit * item.quantity;
            
            totalUtility += itemUtility;
            totalPrice += itemPrice;
            totalProfit += itemProfit;
            
            const itemElement = document.createElement("div");
            itemElement.className = "product-item";
            itemElement.innerHTML = `
                <p>${product.name} x ${item.quantity}</p>
                <p>Полезност: ${itemUtility.toFixed(2)}</p>
                <p>Цена: ${itemPrice.toFixed(2)} лв.</p>
                <button onclick="removeFromPackage(${packageId}, ${index})">Премахни</button>
            `;
            packageElement.appendChild(itemElement);
        }
    });
    
    packages[packageId].utility = totalUtility;
    packages[packageId].price = totalPrice;
    packages[packageId].profit = totalProfit;
    
    const utilityElement = document.getElementById(`utility${packageId}`);
    const priceElement = document.getElementById(`price${packageId}`);
    const profitElement = document.getElementById(`profit${packageId}`);
    
    if (utilityElement) utilityElement.textContent = totalUtility.toFixed(2);
    if (priceElement) priceElement.textContent = totalPrice.toFixed(2);
    if (profitElement) profitElement.textContent = totalProfit.toFixed(2);
    
    updatePayoffMatrix();
}

// Актуализиране на настройките за проучване
function updateSurveySettings() {
    const newScale = parseInt(document.getElementById("surveyScale").value);
    if (newScale > 0) {
        surveyScale = newScale;
        updateSurveyProducts();
    }
}

// Визуализация на полета за въвеждане на данни от проучване
function updateSurveyProducts() {
    const container = document.getElementById("surveyProducts");
    if (!container) return;
    
    container.innerHTML = "";
    
    if (products.length === 0) {
        container.innerHTML = "<p>Няма въведени продукти.</p>";
        return;
    }
    
    products.forEach(product => {
        const productSection = document.createElement("div");
        productSection.className = "survey-section";
        
        const productHeader = document.createElement("h4");
        productHeader.textContent = product.name;
        productSection.appendChild(productHeader);
        
        const surveyGrid = document.createElement("div");
        surveyGrid.className = "survey-grid";
        
        customerGroups.forEach(group => {
            const groupItem = document.createElement("div");
            groupItem.className = "survey-item";
            
            const groupLabel = document.createElement("p");
            groupLabel.textContent = group;
            groupItem.appendChild(groupLabel);
            
            // Създаване на input за оценка
            const inputId = `survey_${product.id}_${group.replace(/\s+/g, '_')}`;
            const input = document.createElement("input");
            input.type = "number";
            input.id = inputId;
            input.min = "1";
            input.max = surveyScale;
            input.step = "1";
            input.value = getSurveyValue(product.id, group);
            input.addEventListener("change", () => {
                saveSurveyValue(product.id, group, parseFloat(input.value));
            });
            groupItem.appendChild(input);
            
            // Индикация за скалата
            const scaleInfo = document.createElement("div");
            scaleInfo.className = "survey-scale";
            scaleInfo.innerHTML = `<span>0</span><span>${surveyScale}</span>`;
            groupItem.appendChild(scaleInfo);
            
            surveyGrid.appendChild(groupItem);
        });
        
        productSection.appendChild(surveyGrid);
        container.appendChild(productSection);
    });
}

// Запазване на стойност от проучване
function saveSurveyValue(productId, group, value) {
    if (!surveyResults[productId]) {
        surveyResults[productId] = {};
    }
    surveyResults[productId][group] = value;
    updatePayoffMatrix();
}

// Взимане на стойност от проучване
function getSurveyValue(productId, group) {
    if (surveyResults[productId] && surveyResults[productId][group] !== undefined) {
        return surveyResults[productId][group];
    }
    // Генериране на примерна стойност между 1 и максималната стойност на скалата
    return Math.floor(Math.random() * surveyScale * 100) / 100;
}

// Изчисляване и визуализация на платежна матрица с Ентропия на Шанън
function updatePayoffMatrix() {
    const matrixBody = document.getElementById("payoffMatrixBody");
    const probabilitiesBody = document.getElementById("probabilitiesTableBody");
    
    if (!matrixBody || !probabilitiesBody) return;
    
    matrixBody.innerHTML = "";
    probabilitiesBody.innerHTML = "";
    
    payoffMatrix = [];
    
    // За всеки пакет, изчисляваме оценката спрямо всяка група клиенти
    for (let packageId = 1; packageId <= 3; packageId++) {
        const packageRow = [];
        const pkg = packages[packageId];
        
        const row = document.createElement("tr");
        const cell = document.createElement("td");
        cell.textContent = `Пакет ${packageId}`;
        row.appendChild(cell);
        
        customerGroups.forEach(group => {
            let groupRating = 0;
            
            // Изчисляване на сума от оценки за продуктите в пакета от тази група клиенти
            pkg.items.forEach(item => {
                const product = products.find(p => p.id === item.productId);
                if (product) {
                    const surveyValue = getSurveyValue(product.id, group);
                    groupRating += surveyValue * item.quantity;
                }
            });
            
            packageRow.push(groupRating);
            
            const ratingCell = document.createElement("td");
            ratingCell.textContent = groupRating.toFixed(2);
            row.appendChild(ratingCell);
        });
        
        // Добавяме място за крайната оценка от модела (ще се попълни по-късно)
        const finalRatingCell = document.createElement("td");
        finalRatingCell.id = `packageFinalRating${packageId}`;
        finalRatingCell.textContent = "-";
        row.appendChild(finalRatingCell);
        
        payoffMatrix.push(packageRow);
        matrixBody.appendChild(row);
    }
    
    // Проверка дали има данни в матрицата
    if (payoffMatrix.length === 0 || payoffMatrix.every(row => row.every(val => val === 0))) {
        const bestPackageElement = document.getElementById("bestPackage");
        if (bestPackageElement) {
            bestPackageElement.textContent = "Все още няма данни";
        }
        return;
    }
    
    // Изчисляване на вероятностите чрез Ентропия на Шанън
    const groupEntropies = [];
    const groupProbabilities = [];
    
    // За всяка група клиенти
    for (let colIndex = 0; colIndex < customerGroups.length; colIndex++) {
        // Извличане на стойностите за тази група от всички пакети
        const columnValues = payoffMatrix.map(row => row[colIndex]);
        const sum = columnValues.reduce((acc, val) => acc + val, 0);
        
        if (sum === 0) {
            // Ако сумата е 0, задаваме равни вероятности
            groupEntropies.push(1);
            groupProbabilities.push(0);
            continue;
        }
        
        // Изчисляване на вероятностите за всеки пакет
        const probabilities = columnValues.map(val => val / sum);
        
        // Изчисляване на Ентропия на Шанън: -1/ln(n) * sum(p_i * ln(p_i))
        const n = payoffMatrix.length; // брой пакети
        
        let entropy = 0;
        probabilities.forEach(p => {
            if (p > 0) {
                entropy += p * Math.log(p);
            }
        });
        entropy = -1 / Math.log(n) * entropy;
        
        // Изчисляване на 1-Ентропия
        const oneMinusEntropy = 1 - entropy;
        
        groupEntropies.push(entropy);
        groupProbabilities.push(oneMinusEntropy);
    }
    
    // Нормализиране на вероятностите
    const sumProbabilities = groupProbabilities.reduce((acc, val) => acc + val, 0);
    const normalizedProbabilities = sumProbabilities > 0 ? 
        groupProbabilities.map(p => p / sumProbabilities) : 
        groupProbabilities.map(() => 1 / groupProbabilities.length);
    
    // Показване на таблица с вероятностите
    customerGroups.forEach((group, index) => {
        const row = document.createElement("tr");
        
        const groupCell = document.createElement("td");
        groupCell.textContent = group;
        row.appendChild(groupCell);
        
        const entropyCell = document.createElement("td");
        entropyCell.textContent = groupEntropies[index].toFixed(4);
        row.appendChild(entropyCell);
        
        const oneMinusEntropyCell = document.createElement("td");
        oneMinusEntropyCell.textContent = groupProbabilities[index].toFixed(4);
        row.appendChild(oneMinusEntropyCell);
        
        const normalizedProbCell = document.createElement("td");
        normalizedProbCell.textContent = normalizedProbabilities[index].toFixed(4);
        row.appendChild(normalizedProbCell);
        
        probabilitiesBody.appendChild(row);
    });
    
    // Изчисляване на крайните оценки за всеки пакет
    const finalPackageRatings = [];
    
    for (let packageIndex = 0; packageIndex < payoffMatrix.length; packageIndex++) {
        let finalRating = 0;
        
        for (let groupIndex = 0; groupIndex < customerGroups.length; groupIndex++) {
            // Умножаване на стойността в матрицата по съответната вероятност на групата
            finalRating += payoffMatrix[packageIndex][groupIndex] * normalizedProbabilities[groupIndex];
        }
        
        finalPackageRatings.push(finalRating);
        
        // Актуализиране на крайната оценка в таблицата
        const finalRatingElement = document.getElementById(`packageFinalRating${packageIndex + 1}`);
        if (finalRatingElement) {
            finalRatingElement.textContent = finalRating.toFixed(2);
        }
    }
    
    // Намиране на най-добрия пакет
    const bestPackageIndex = finalPackageRatings.indexOf(Math.max(...finalPackageRatings));
    const bestPackageElement = document.getElementById("bestPackage");
    if (bestPackageElement) {
        bestPackageElement.textContent = `Пакет ${bestPackageIndex + 1} с оценка ${finalPackageRatings[bestPackageIndex].toFixed(2)}`;
    }
    
    // Актуализиране на графиката
    updateChart(normalizedProbabilities);
}

// Визуализация на графика с нормализирани вероятности
function updateChart(normalizedProbabilities) {
    const canvas = document.getElementById('packageChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Унищожаване на предишната графика, ако има такава
    if (chart) {
        chart.destroy();
    }
    
    // Проверка дали Chart.js е зареден
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js не е зареден');
        return;
    }
    
    // Трансформиране на данните за графиката
    const datasets = [];
    for (let i = 0; i < 3; i++) {
        if (payoffMatrix[i] && payoffMatrix[i].length > 0) {
            // Копираме данните от платежната матрица и ги умножаваме по вероятностите
            const weightedData = payoffMatrix[i].map((value, index) => 
                value * normalizedProbabilities[index]);
            
            datasets.push({
                label: `Пакет ${i + 1}`,
                data: weightedData,
                backgroundColor: getColorForPackage(i + 1, 0.2),
                borderColor: getColorForPackage(i + 1),
                borderWidth: 1
            });
        }
    }
    
    // Създаване на нова графика (bar chart)
    chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: customerGroups,
            datasets: datasets
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Претеглена оценка (стойност × вероятност)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Група клиенти'
                    }
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Анализ на пакетите по целеви групи'
                }
            }
        }
    });
}

// Помощна функция за определяне на цвят за пакет
function getColorForPackage(packageId, alpha = 1) {
    const colors = [
        'rgba(76, 175, 80, ' + alpha + ')',   // Зелен
        'rgba(33, 150, 243, ' + alpha + ')',  // Син
        'rgba(255, 193, 7, ' + alpha + ')'    // Жълт
    ];
    return colors[(packageId - 1) % colors.length];
}

// Добавяне на примерни продукти според данните от заданието
function addSampleProducts() {
    // Изчистване на съществуващи продукти
    products = [];
    surveyResults = {};
    
    // Добавяне на примерните продукти
    const sampleProducts = [
        {
            name: "Покана (дигитална)",
            time: 90, // 1 час и 30 минути
            price: 10,
            cost: 0,
            profit: 10,
            profitPercentage: 100
        },
        {
            name: "Декорация за сладкиши (12 броя)",
            time: 260, // 4 часа + 20 мин
            price: 9.6,
            cost: 0.8,
            profit: 8.8,
            profitPercentage: 91.67
        },
        {
            name: "Аксесоари за снимки (12 броя)",
            time: 260, // 4 часа + 20 мин
            price: 9.6,
            cost: 1.6,
            profit: 8,
            profitPercentage: 83.33
        },
        {
            name: "Банер/надпис (16 букви)",
            time: 280, // 4 часа и 40 мин
            price: 25,
            cost: 3.2,
            profit: 21.8,
            profitPercentage: 87.20
        },
        {
            name: "Табло за добре дошли",
            time: 180, // 3 часа
            price: 30,
            cost: 8,
            profit: 22,
            profitPercentage: 73.33
        },
        {
            name: "Табло с отпечатъци",
            time: 180, // 3 часа
            price: 40,
            cost: 12,
            profit: 28,
            profitPercentage: 70.00
        },
        {
            name: "Игри за парти \"Мама или тати\" (12 броя)",
            time: 150, // 2 часа и 30 мин
            price: 19.2,
            cost: 2.4,
            profit: 16.8,
            profitPercentage: 87.50
        },
        {
            name: "Игри за парти \"Предположения и съвети\"",
            time: 150, // 2 часа и 30 мин
            price: 19.2,
            cost: 2.4,
            profit: 16.8,
            profitPercentage: 87.50
        },
        {
            name: "Игри за парти \"Име на бебето\"",
            time: 150, // 2 часа и 30 мин
            price: 19.2,
            cost: 2.4,
            profit: 16.8,
            profitPercentage: 87.50
        }
    ];
    
    // Добавяне на продуктите със съответните ID
    sampleProducts.forEach((product, index) => {
        products.push({
            id: Date.now().toString() + index.toString() + Math.random().toString(36).substring(2, 9),
            name: product.name,
            time: product.time,
            price: product.price,
            cost: product.cost,
            profit: product.profit,
            profitPercentage: product.profitPercentage,
            utility: 0 // ще се изчисли по-късно
        });
    });
    
    updateProductUtility();
    renderProductsTable();
    updateProductSelect();
    updateSurveyProducts();
    
    // Изчистване на пакетите
    for (let packageId in packages) {
        packages[packageId].items = [];
        updatePackageSummary(packageId);
    }
    
    alert("Примерните продукти бяха добавени успешно!");
}

// Инициализация при зареждане на страницата
document.addEventListener('DOMContentLoaded', function() {
    init();
});

// За съвместимост със стари браузъри
window.onload = function() {
    if (document.readyState === 'complete') {
        init();
    }
};